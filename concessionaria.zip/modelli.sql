-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Apr 29, 2024 alle 09:43
-- Versione del server: 10.4.17-MariaDB
-- Versione PHP: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_christiancalvano`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `modelli`
--

CREATE TABLE `modelli` (
  `id_modello` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `id_casa` int(11) NOT NULL,
  `id_alimentazione` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `id_cilindrata` int(11) NOT NULL,
  `prezzo` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `modelli`
--
ALTER TABLE `modelli`
  ADD PRIMARY KEY (`id_modello`),
  ADD KEY `id_casa` (`id_casa`),
  ADD KEY `id_alimentazione` (`id_alimentazione`),
  ADD KEY `id_categoria` (`id_categoria`),
  ADD KEY `id_cilindrata` (`id_cilindrata`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `modelli`
--
ALTER TABLE `modelli`
  MODIFY `id_modello` int(11) NOT NULL AUTO_INCREMENT;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `modelli`
--
ALTER TABLE `modelli`
  ADD CONSTRAINT `modelli_ibfk_1` FOREIGN KEY (`id_casa`) REFERENCES `case_automobilistiche` (`id_casa`) ON UPDATE CASCADE,
  ADD CONSTRAINT `modelli_ibfk_2` FOREIGN KEY (`id_alimentazione`) REFERENCES `alimentazioni` (`id_alimentazione`) ON UPDATE CASCADE,
  ADD CONSTRAINT `modelli_ibfk_3` FOREIGN KEY (`id_categoria`) REFERENCES `categorie` (`id_categoria`) ON UPDATE CASCADE,
  ADD CONSTRAINT `modelli_ibfk_4` FOREIGN KEY (`id_cilindrata`) REFERENCES `cilindrate` (`id_cilindrata`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
